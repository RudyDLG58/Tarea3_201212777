import java.util.Scanner;


public class Par_impar {

	public static void main(String[] args) {
		Scanner S = new Scanner (System.in);
		System.out.println("Introdusca numero");
		int num=1;
		num = S.nextInt();

				if ( num%2==0 )
					System.out.println("Es par");
				else 
					System.out.println("Es impar");

	}

}
